import java.util.Random;
public class Tester {
    private final SortingAlgorithm sortingAlgorithm;

    public Tester(SortingAlgorithm sa) {
        this.sortingAlgorithm = sa;
    }

    public double singleTest(int size) {
        Random random = new Random();
        int[] array = new int[size];
        for(int i = 0; i < size; i++) {
            array[i] = random.nextInt(size);
        }

        long startTime = System.currentTimeMillis();
        sortingAlgorithm.sorty(array);
        long endTime = System.currentTimeMillis();
        return  endTime - startTime;
    }

    public void test(int iterations, int size) {
        double total = 0;
        for(int i  = 0; i < iterations; i++) {
            total += singleTest(size);
        }
        double averageTime = total / iterations;
        System.out.println("Sorted " + size + " elements in " + averageTime + " ms (avg)");
    }

}
