public class QuickSort implements SortingAlgorithm {

    public int[] sorty(int[] input) {
        quickSort(input, 0, input.length - 1);
        return input;
    }

    private void quickSort(int[] input, int start, int end) {

        if (start < end) {
            //partition the array and gets the pivot position
            int pivot = partition(input, start, end);
            //recursively sort the elements before and after partition
            quickSort(input, start, pivot - 1);
            quickSort(input, pivot + 1, end);
        }
    }

    private int partition(int[] input, int start, int end) {
        //selects last element as partition
        int pivot = input[end];
        int i = start - 1;
        //place elements smaller than the pivot
        for(int j = start; j <= end - 1; j++) {
            //check if element is smaller than pivot
            if(input[j] < pivot) {
                i++;
                //swaps elements at i and j
                int temp = input[i];
                input[i] = input [j];
                input[j] = temp;

            }
        }
        //swap pivot element into correct position
        i++;
        int temp = input[i];
        input[i] = input[end];
        input[end] = temp;
        return i;

    }
}

