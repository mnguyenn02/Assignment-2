
public class BubbleSort implements SortingAlgorithm {
    public int[] sorty(int[] input) {

        for (int i = 0; i < input.length - 1; i++)
            //goes through all elements in the array to sort
            for (int j = 0; j < input.length - i - 1; j++)
                //if element is larger than next element, it swaps
                if (input[j] > input[j + 1]) {
                    //swap element with temporary variable
                    int temp = input[j];
                    input[j] = input[j + 1];
                    input[j + 1] = temp;

                }

        return input;

            }

        }
