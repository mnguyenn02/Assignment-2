public class InsertionSort implements SortingAlgorithm {
    public int[] sorty(int[] input) {

        for(int i = 1; i < input.length; i++) {
            //store current element
            int array = input[i];
            int j = i - 1;
            //shift elements larger than current value one position right
            while (j >= 0 && input[j] > array) {
                //shift elements right until correct position
                input[j + 1] = input[j];
                j = j - 1;

            }
            //insert stored element into correct position
            input[j + 1] = array;
        }

        return input;

        }
    }
