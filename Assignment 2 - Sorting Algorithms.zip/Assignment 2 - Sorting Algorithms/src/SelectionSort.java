public class SelectionSort implements SortingAlgorithm {
    public int[] sorty(int[] input) {

        for (int i = 0; i < input.length - 1; i++) {
            //current position is the smallest
            int min = i;
            //find index of smallest number in the array
            for (int j = i + 1; j < input.length; j++) {
                //replace if a smaller number is found
                if (input[j] < input[min])
                    min = j;

            }
            //swaps minimum element with element in current position
            int temp = input[min];
            input[min] = input[i];
            input[i] = temp;

        }

        return input;

    }
}
