public class ShellSort implements SortingAlgorithm {
    public int[] sorty(int[] input) {
        //initial gap size
        for(int gap = input.length / 2; gap > 0; gap /= 2) {
            //insertion sort for each gap size
            for(int i = gap; i < input.length; i += 1 ) {
                //store temporary element to be inserted in the array
                int temp = input[i];
                //shift elements right until correct position for temp
                for (int j = i; j >= gap && input[j - gap] > temp; j -= gap) {
                    //move elements right
                    input[j] = input[j - gap];
                    //insert element to correct position
                    input[j] = temp;

                }
            }
        }
        return input;
    }
}
