
public class Performance {

    public static void main(String[] args) {

        SortingAlgorithm[] algorithms = {
                new BubbleSort(), new InsertionSort(), new SelectionSort(), new ShellSort(), new QuickSort() };

        String[] sortNames = {
                "BubbleSort", "InsertionSort", "SelectionSort", "ShellSort", "QuickSort" };

        int[] sizes = {100, 500, 1000, 2000, 5000, 10000, 20000, 75000, 150000};
        int iterations = 20;

        for(int i = 0; i < algorithms.length; i++) {
            SortingAlgorithm sortingAlgorithm = algorithms[i];
            System.out.println("Sorting algorithm - " + sortNames[i]);
            Tester tester = new Tester(sortingAlgorithm);

            for(int size : sizes) {
                tester.test(iterations, size);
            }
            System.out.println();
        }
    }
}
