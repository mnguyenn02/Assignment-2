public interface SortingAlgorithm {
    int[] sorty(int[] input);

}
